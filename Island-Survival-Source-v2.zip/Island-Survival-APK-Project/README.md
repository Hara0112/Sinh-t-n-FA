# Island Survival
Prototype game đảo hoang 3D dùng Three.js, có điều khiển cảm ứng, thu thập gỗ/đá/lá và chỉ số sinh tồn.

## Build APK bằng GitHub Actions
1. Tải và giải nén toàn bộ dự án này.
2. Đưa các tệp/thư mục bên trong vào repository `Hara0112/Island-Survival` trên nhánh `main`.
3. Mở tab **Actions**, chọn **Build Island Survival APK** (hoặc đợi workflow tự chạy sau push).
4. Khi run hoàn tất thành công, tải artifact `Island-Survival-debug-apk`.

Đây là APK debug để cài thử, chưa phải bản phát hành ký số. Workflow tạo APK tự động; không chứa APK dựng sẵn.

## Chạy web local
`npm install` rồi `npm run dev`.

## Phạm vi hiện tại
Đây là MVP nền tảng. Chưa có multiplayer/server, voice chat, lưu cloud, chế tạo nâng cao, hệ thống nhiệm vụ hay kiểm thử thiết bị thực tế.
